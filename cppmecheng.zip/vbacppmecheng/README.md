# vbacppmecheng
Tutorial self-teaching my VBA code from YouTube CPPMechEngTutorials.
