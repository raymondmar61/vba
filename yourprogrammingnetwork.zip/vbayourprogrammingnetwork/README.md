# vbayourprogrammingnetwork
Tutorial self-teaching my VBA code from YouTube YourProgrammingNetwork.
