# vbamicrosoftexcelprogramming
Tutorial self-teaching my VBA code from book Microsoft Excel Programming.
