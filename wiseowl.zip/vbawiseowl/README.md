# vbawiseowl
Tutorial self-teaching my VBA code from YouTube Wise Owl.
